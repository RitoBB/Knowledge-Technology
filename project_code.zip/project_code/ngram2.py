
# coding: utf-8

# In[9]:


import nltk
d = []
with open('dict.txt') as inputfile:
    for line in inputfile:
        d.append(line.strip())

wiki_misspell = []
with open('wiki_misspell.txt') as inputfile:
    for line in inputfile:
        wiki_misspell.append(line.strip())
        
def ngrams(words, n):
    char = list(words)
    return [ char[i:i+n] for i in range(len(char)-n+1) ]

import timeit

import nltk
f = open("./dict.txt",'r')
my_dict = f.readlines()
f.close()


# In[15]:


dic = []
with open('dict.txt') as inputfile:
    for line in inputfile:
        dic.append(line.strip())
        
wiki_misspell = []
with open('wiki_misspell.txt') as inputfile:
    for line in inputfile:
        wiki_misspell.append(line.strip())

correct = []
with open('wiki_correct.txt') as inputfile:
    for line in inputfile:
        correct.append(line.strip())

start = timeit.default_timer()

att_response = 0
count = 0

for i in range(len(wiki_misspell)):
    string = wiki_misspell[i].strip()
    wiki_chars = set(nltk.ngrams(string, 2))
    bestv = 10000000 # This is intentionally overkill
    bests_test = []
    bests_final = []
    response = []
    for entry in dic:
        y_chars = set(nltk.ngrams(entry, 2))
        thisv = nltk.jaccard_distance(wiki_chars,y_chars)
        if (thisv <= bestv):
            response.append(thisv)
            bests_test.append(entry.strip()) 
            bestv = thisv
    min_value = min(response)
    min_index = [i for i, x in enumerate(response) if x == min_value]
    for x in min_index:
        bests_final.append(bests_test[x])
    att_response = len(bests_final) + att_response
    print(string, ": ", min_value)
    for j in range(len(bests_final)):
        if bests_final[j] == correct[i]:
            count = count+1
            print("               ",bests_final[j],'☑️')
        else:
            print("               ",bests_final[j],'❌')
print('All attempt response: ', att_response)

recall = count/4453
precision = count/att_response

print('Recall: ', recall)
print('Precision: ', precision)

stop = timeit.default_timer()
print('Time: ', stop - start) 


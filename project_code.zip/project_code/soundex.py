
# coding: utf-8

# In[50]:


import soundex


# In[51]:


import timeit


# In[35]:


import nltk


# In[48]:


f = open("./dict.txt",'r')
my_dict = f.readlines()
f.close()


# In[52]:


dic = []
with open('dict.txt') as inputfile:
    for line in inputfile:
        dic.append(line.strip())
        
wiki_misspell = []
with open('wiki_misspell.txt') as inputfile:
    for line in inputfile:
        wiki_misspell.append(line.strip())

correct = []
with open('wiki_correct.txt') as inputfile:
    for line in inputfile:
        correct.append(line.strip())

start = timeit.default_timer()
s = soundex.getInstance()
att_response = 0
count = 0

for i in range(len(wiki_misspell)):
    string = wiki_misspell[i].strip()
    wiki_soundex = s.soundex(string)
    bests_final = []
    for entry in dic:
        y_soundex = s.soundex(entry)
        if (wiki_soundex == y_soundex):
            bests_final.append(entry.strip()) 
    att_response = len(bests_final) + att_response
    print(string, ": ", wiki_soundex)
    for j in range(len(bests_final)):
        if bests_final[j] == correct[i]:
            count = count+1
            print("             ",bests_final[j],'☑️')
        else:
            print("             ",bests_final[j],'❌')
print('All attempt response: ', att_response)


recall = count/4453
precision = count/att_response

print('Recall: ', recall)
print('Precision: ', precision)

stop = timeit.default_timer()
print('Time: ', stop - start) 


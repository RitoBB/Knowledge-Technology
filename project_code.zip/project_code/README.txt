This README describes the program that used for COMP90049 2018S2, Project 1.
This archive contains three files, of which the global edit distance code, sounded and n-gram.
This files are described in more detail below.

  - editDistance.py: This is a code about global edit distance method, which import the package of editdistance in python. The code is slightly-altered version of the data from unimelb.lms that professor gave on the discussion board.

  - n-gram.py: The code imports the nltk package in python and it is about n-gram approximate string matching system. This is a customized code. The package used in this program comes from the following page:
     https://www.nltk.org/

  -soundex.py: This is a program about soundex method and is written in python. The package it used is sick-learn and  comes from the following page:
    http://scikit-learn.org/stable/